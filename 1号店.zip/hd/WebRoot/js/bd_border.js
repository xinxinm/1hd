$(document).ready(function(){
	$('#user').click(function(){
		$('#user').css('border','2px solid #FCBB4F');
		$('#pwd').css('border','1px solid #DBDBDB')
	
	})

	$('#pwd').click(function(){
		$('#pwd').css('border','2px solid #FCBB4F');
		$('#user').css('border','1px solid #DBDBDB')
	
	})
})